﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;                  //기본 패키지에는 제공되어있지 않아서 Nuget 패키지에서 설치해야됨
using System.Runtime.InteropServices;   //시스템 시간 변경을 위해서 참조
using System.Diagnostics; //디버깅용

namespace Time_Synch_Program
{
    public partial class Main : Form
    {
        SerialPort m_sp1;   //시리얼포트 변수

        public struct SYSTEMTIME    //public 선언안하고 쓰면 CS0051 오류 발생
        {
            public ushort wYear; 
            public ushort wMonth; 
            public ushort wDayOfWeek;
            public ushort wDay; 
            public ushort wHour; 
            public ushort wMinute; 
            public ushort wSecond;
            public ushort wMilliseconds;
        }

        [DllImport("kernel32.dll",SetLastError = true)] //SetSystemTime API를 이용하기 위한 연관 시스템 파일
        public extern static bool SetSystemTime(ref SYSTEMTIME st); //시스템 시간을 변경하는 API

        [DllImport("kernel32.dll",SetLastError = true)] //SetLocaltime API를 이용하기 위한 연관 시스템 파일
        public extern static bool SetLocalTime(ref SYSTEMTIME st);  //시스템 시간을 변경하는 API

        public Main()
        {
            InitializeComponent();

            //Timer를 이용하여 현재 PC의 시간을 계속해서 갱신한다.
            PC_Timer.Enabled = true;
            PC_Timer.Tick += PC_Timer_Tick;
            /*
            Properties 안에 있는 Last_Server_Time은 DateTime 형식으로 바꿔서 사용하는게 훨씬 편할 듯 
            */
        }

        //시간이 지날때마다 PC_Timer_Tick 가 갱신됨
        private void PC_Timer_Tick(object sender, EventArgs e)
        {
            //현재 PC의 시간정보를 문자열 형식으로 변환하여 텍스트에 넣어줌 -> 텍스트 아니어도 라벨에 넣으면 더 이쁠듯
            PC_Hour.Text = System.DateTime.Now.ToString("HH");
            PC_Min.Text = System.DateTime.Now.ToString("mm");
            PC_Sec.Text = System.DateTime.Now.ToString("ss");
            PC_Time.Text = Properties.Settings.Default.Last_Server_Time.ToString();                 //시간이 지날때마다 PC_Time을 갱신 -> RX 버튼을 누르거나 데이터를 받아왔을 때 갱신하면 됨
            PC_Time_Delayed.Text = Properties.Settings.Default.Last_Server_Time_Delayed.ToString(); //시간이 지날때마다 PC_Time을 갱신 -> RX 버튼을 누르거나 데이터를 받아왔을 때 갱신하면 됨

            //연결 상태 이미지 변경
            if (m_sp1 == null) 
            {
                Port_Connect_Status.Image = Properties.Resources.RC1;
                Sync_Status.Image = Properties.Resources.RC1;
                TX_Status.Image = Properties.Resources.RC1;
            }
            else {
                if (m_sp1.IsOpen&&m_sp1.ReadExisting() != "")
                {
                    MessageBox.Show(m_sp1.ReadExisting());
                    TX_Status.Image = Properties.Resources.GC1;
                }
                else
                {
                    TX_Status.Image = Properties.Resources.YC1;
                }
                Port_Connect_Status.Image = Properties.Resources.GC1;
                Sync_Status.Image = Properties.Resources.GC1;
            }
        }

        private void Main_Load(object sender, EventArgs e)
        {
            txtComNum.Text = "COM2";
            txtBaudRate.Text = "9600";
            PC_Time.Text = Properties.Settings.Default.Last_Server_Time.ToString();                //속성에 저장되어있는 Last_Server_Time을 불러와서 Text에 저장
            PC_Time_Delayed.Text = Properties.Settings.Default.Last_Server_Time_Delayed.ToString();//속성에 저장되어있는 Last_Server_Time_Delayed을 불러와서 Text에 저장
        }

        private void btn_Open_Click(object sender, EventArgs e)
        {
            try
            {
                if (null == m_sp1)
                {
                    m_sp1 = new SerialPort();
                    m_sp1.PortName = txtComNum.Text;    //컴포트명
                    m_sp1.BaudRate = Convert.ToInt32(txtBaudRate.Text); //바우드레이트
                    m_sp1.Parity = Parity.None;
                    m_sp1.DataBits = 8;
                    m_sp1.StopBits = StopBits.One;

                    m_sp1.DataReceived += new SerialDataReceivedEventHandler(EventDataReceived);
                    m_sp1.Open();
                }

                btn_Open.Enabled = false;   //Open Button Disable
                btn_Close.Enabled = true;    //Close Button Enable
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btn_Close_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.Last_Server_Time = System.DateTime.Now;  //Close 버튼 누를때마다 바뀐 시간 설정을 저장
            DateTime temp = System.DateTime.Now.AddSeconds(1);  //시간 지연
            Properties.Settings.Default.Last_Server_Time_Delayed = temp; //Close 버튼 누를때마다 바뀐 시간 설정을 저장
            Properties.Settings.Default.Save(); //설정 저장

            if(null != m_sp1)
            {
                if (m_sp1.IsOpen)
                {
                    m_sp1.Close();
                    m_sp1.Dispose();
                    m_sp1 = null;
                }
                btn_Open.Enabled = true;    //Open Button Enable
                btn_Close.Enabled = false;  //Close Button Disable
            }

        }

        private void EventDataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            int iRecSize = m_sp1.BytesToRead; // 수신된 데이터 갯수
            string strRxData;   //수신 데이터 문자열

            try
            {
                if (iRecSize != 0) // 수신된 데이터의 수가 0이 아닐때만 처리하자
                {
                    strRxData = "";
                    byte[] buff = new byte[iRecSize];

                    m_sp1.Read(buff, 0, iRecSize);

                    Debug.WriteLine(strRxData);
                    for (int iTemp = 0; iTemp < iRecSize; iTemp++)
                    {
                        strRxData += Convert.ToChar(buff[iTemp]);
                    }
                    Debug.WriteLine(strRxData);
                    //MessageBox.Show(strRxData);
                }
            }
            catch (System.Exception ex)
            {
                Debug.WriteLine(ex.Message);
                //MessageBox.Show(ex.Message);
            }
        }

        private void pharsingMsg(string Msg,bool isSave)
        {
            string latitude = null;         //위도
            string longitude = null;        //경도
            string reception_time = "";     //수신시간
            string GPS_reception_type = ""; //GPS 수신종류
            string count_setellite = "";    //위성갯수
            string altitude = "";           //고도(해수면기준)

            string[] ChkMsg = null;
            string temp = "";
            if(Msg == null || Msg.Equals(""))
            {

            }
            else
            {
                try
                {
                    Msg.Replace("\n\r", "");
                    int selectIDX = -1;
                    string[] strArr = Msg.Split('$');
                    //최근의 GPGGA 문자열 찾기
                    for(int i = strArr.Length - 1; i >= 0; i--)
                    {
                        if (strArr[i].ToString().Substring(0, 5).Equals("GPGGA"))
                        {
                            ChkMsg = strArr[i].ToString().Split(',');
                            if(ChkMsg[2] == null || ChkMsg[3] == null || ChkMsg[4] == null || ChkMsg[5] == null)
                            {
                                continue;
                            }
                            else if(ChkMsg[2].ToString().Replace(" ","").Equals("")|| ChkMsg[3].ToString().Replace(" ", "").Equals("") || ChkMsg[4].ToString().Replace(" ", "").Equals("") || ChkMsg[5].ToString().Replace(" ", "").Equals(""))
                            {
                                continue;
                            }
                            else
                            {
                                selectIDX = i;
                                break;
                            }
                        }
                    }
                    //수신 문자열중 GPGGA가 없을 때
                    if(selectIDX < 0)
                    {
                        latitude = null;
                        longitude = null;
                        reception_time = "";
                        GPS_reception_type = "";
                        count_setellite = "";
                        altitude = "";
                    }
                    else
                    {
                        string[] ArrMsg = ChkMsg;
                        temp = ArrMsg[1].ToString();
                        int hour = Convert.ToInt16(temp.Substring(0, 2)) + 9;
                        if (hour > 24)
                        {
                            hour = hour = 24;
                        }
                        //string 대신 datatime 형식으로 변환해서 사용하면 될 듯
                        reception_time = "" + hour + "시";
                        reception_time = " " + temp.Substring(2, 2) + "분 " + temp.Substring(4, 5) + "초";
                        latitude = ArrMsg[2].ToString();
                        longitude = ArrMsg[4].ToString();

                        GPS_reception_type = ArrMsg[6].ToString();
                        count_setellite = ArrMsg[7].ToString();
                        altitude = ArrMsg[9].ToString();
                    }
                }
                catch(Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                }
            }
        }

        /*
        private void btn_RX_Click(object sender, EventArgs e)
        {
            int iRecSize = m_sp1.BytesToRead;   //수신된 데이터 갯수
            string strRxData;   //수신된 데이터를 문자열로 변환
            //받아온 데이터를 시 분 초로 변환하여 저장하고 지연시간을 확인해서 그만큼 추가해주면 됨

            //strRxData 변수에다 수신된 데이터를 문자열로 변환하고 메세지 박스로 보여준다.
            try
            {
                if(iRecSize != 0)
                {
                    strRxData = "";
                    byte[] buff = new byte[iRecSize];

                    m_sp1.Read(buff, 0, iRecSize);
                    for(int iTemp = 0; iTemp < iRecSize; iTemp++)
                    {
                        strRxData += Convert.ToChar(buff[iTemp]);
                    }
                    MessageBox.Show(strRxData);
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        */
        private void btn_Time_Apply_Click(object sender, EventArgs e)
        {
            SYSTEMTIME st = new SYSTEMTIME();

            //tmpdata 안에 변경할 시간 정보들을 변수로 넘겨주면 된다.
            //DateTime tmpdate = new DateTime(st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);    
            DateTime tmpdate = Properties.Settings.Default.Last_Server_Time_Delayed;

            tmpdate = tmpdate.AddHours(-9); //KOR timezone adjust

            st.wYear = (ushort)tmpdate.Year;
            st.wDayOfWeek = (ushort)tmpdate.DayOfWeek; 
            st.wMonth = (ushort)tmpdate.Month; 
            st.wDay = (ushort)tmpdate.Day; 
            st.wHour = (ushort)tmpdate.Hour; 
            st.wMinute = (ushort)tmpdate.Minute; 
            st.wSecond = (ushort)tmpdate.Second; 
            st.wMilliseconds = 0; 

            bool E = SetSystemTime(ref st);
            
            //MessageBox.Show(tmpdate.ToString());  //바뀐 시간 체크

            //에러 체크 -> 87인데 형식이 뭔가 잘못된것같음 -> wYear를 초기화하지 않아서 생긴 오류
            //에러 체크 -> 1314 : 관리자 권한 -> 빌드하고 관리자 권한으로 열기하면 됨
            if (E == false)
            {
                int lastError = Marshal.GetLastWin32Error();
                MessageBox.Show(lastError.ToString());
            }

        }

    }
}
