﻿
namespace Time_Synch_Program
{
    partial class Main
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.PC_Timer = new System.Windows.Forms.Timer(this.components);
            this.txtComNum = new System.Windows.Forms.TextBox();
            this.label = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtBaudRate = new System.Windows.Forms.TextBox();
            this.btn_Open = new System.Windows.Forms.Button();
            this.btn_Close = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Intranet_Server_Time = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Intranet_Server_Time_Delayed = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.Port_Connect_Status = new System.Windows.Forms.PictureBox();
            this.Sync_Status = new System.Windows.Forms.PictureBox();
            this.TX_Status = new System.Windows.Forms.PictureBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Voip_Server_Time = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Port_Connect_Status)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Sync_Status)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TX_Status)).BeginInit();
            this.SuspendLayout();
            // 
            // PC_Timer
            // 
            this.PC_Timer.Tick += new System.EventHandler(this.PC_Timer_Tick);
            // 
            // txtComNum
            // 
            this.txtComNum.Location = new System.Drawing.Point(77, 13);
            this.txtComNum.Name = "txtComNum";
            this.txtComNum.Size = new System.Drawing.Size(100, 23);
            this.txtComNum.TabIndex = 3;
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Location = new System.Drawing.Point(12, 16);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(40, 15);
            this.label.TabIndex = 4;
            this.label.Text = "Port : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 15);
            this.label2.TabIndex = 5;
            this.label2.Text = "Baud : ";
            // 
            // txtBaudRate
            // 
            this.txtBaudRate.Location = new System.Drawing.Point(77, 46);
            this.txtBaudRate.Name = "txtBaudRate";
            this.txtBaudRate.Size = new System.Drawing.Size(100, 23);
            this.txtBaudRate.TabIndex = 6;
            // 
            // btn_Open
            // 
            this.btn_Open.Location = new System.Drawing.Point(63, 285);
            this.btn_Open.Name = "btn_Open";
            this.btn_Open.Size = new System.Drawing.Size(75, 23);
            this.btn_Open.TabIndex = 7;
            this.btn_Open.Text = "Open";
            this.btn_Open.UseVisualStyleBackColor = true;
            this.btn_Open.Click += new System.EventHandler(this.btn_Open_Click);
            // 
            // btn_Close
            // 
            this.btn_Close.Location = new System.Drawing.Point(168, 285);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(75, 23);
            this.btn_Close.TabIndex = 8;
            this.btn_Close.Text = "Close";
            this.btn_Close.UseVisualStyleBackColor = true;
            this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(-13, -185);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 15);
            this.label1.TabIndex = 10;
            this.label1.Text = "label1";
            // 
            // Intranet_Server_Time
            // 
            this.Intranet_Server_Time.AutoSize = true;
            this.Intranet_Server_Time.Location = new System.Drawing.Point(228, 150);
            this.Intranet_Server_Time.Name = "Intranet_Server_Time";
            this.Intranet_Server_Time.Size = new System.Drawing.Size(117, 15);
            this.Intranet_Server_Time.TabIndex = 11;
            this.Intranet_Server_Time.Text = "Intranet_Server_Time";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(47, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 15);
            this.label3.TabIndex = 12;
            this.label3.Text = "지연시간";
            // 
            // Intranet_Server_Time_Delayed
            // 
            this.Intranet_Server_Time_Delayed.AutoSize = true;
            this.Intranet_Server_Time_Delayed.Location = new System.Drawing.Point(228, 115);
            this.Intranet_Server_Time_Delayed.Name = "Intranet_Server_Time_Delayed";
            this.Intranet_Server_Time_Delayed.Size = new System.Drawing.Size(165, 15);
            this.Intranet_Server_Time_Delayed.TabIndex = 13;
            this.Intranet_Server_Time_Delayed.Text = "Intranet_Server_Time_Delayed";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(47, 150);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 15);
            this.label4.TabIndex = 14;
            this.label4.Text = "인트라넷 서버 시간";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(506, 32);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 15);
            this.label5.TabIndex = 16;
            this.label5.Text = "포트 연결 상태";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(506, 88);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(71, 15);
            this.label6.TabIndex = 17;
            this.label6.Text = "동기화 상태";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(506, 139);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 15);
            this.label7.TabIndex = 18;
            this.label7.Text = "수신 여부 확인";
            // 
            // Port_Connect_Status
            // 
            this.Port_Connect_Status.Image = global::Time_Synch_Program.Properties.Resources.RC1;
            this.Port_Connect_Status.Location = new System.Drawing.Point(610, 13);
            this.Port_Connect_Status.Name = "Port_Connect_Status";
            this.Port_Connect_Status.Size = new System.Drawing.Size(45, 45);
            this.Port_Connect_Status.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Port_Connect_Status.TabIndex = 19;
            this.Port_Connect_Status.TabStop = false;
            // 
            // Sync_Status
            // 
            this.Sync_Status.Image = global::Time_Synch_Program.Properties.Resources.RC1;
            this.Sync_Status.Location = new System.Drawing.Point(610, 70);
            this.Sync_Status.Name = "Sync_Status";
            this.Sync_Status.Size = new System.Drawing.Size(45, 45);
            this.Sync_Status.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Sync_Status.TabIndex = 20;
            this.Sync_Status.TabStop = false;
            // 
            // TX_Status
            // 
            this.TX_Status.Image = global::Time_Synch_Program.Properties.Resources.RC1;
            this.TX_Status.Location = new System.Drawing.Point(610, 123);
            this.TX_Status.Name = "TX_Status";
            this.TX_Status.Size = new System.Drawing.Size(45, 45);
            this.TX_Status.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.TX_Status.TabIndex = 21;
            this.TX_Status.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(47, 191);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 15);
            this.label8.TabIndex = 22;
            this.label8.Text = "Voip 서버 시간";
            // 
            // Voip_Server_Time
            // 
            this.Voip_Server_Time.AutoSize = true;
            this.Voip_Server_Time.Location = new System.Drawing.Point(228, 191);
            this.Voip_Server_Time.Name = "Voip_Server_Time";
            this.Voip_Server_Time.Size = new System.Drawing.Size(101, 15);
            this.Voip_Server_Time.TabIndex = 23;
            this.Voip_Server_Time.Text = "Voip_Server_Time";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(698, 361);
            this.Controls.Add(this.Voip_Server_Time);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.TX_Status);
            this.Controls.Add(this.Sync_Status);
            this.Controls.Add(this.Port_Connect_Status);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Intranet_Server_Time_Delayed);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Intranet_Server_Time);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Close);
            this.Controls.Add(this.btn_Open);
            this.Controls.Add(this.txtBaudRate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label);
            this.Controls.Add(this.txtComNum);
            this.Name = "Main";
            this.Text = "Main";
            this.Load += new System.EventHandler(this.Main_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Port_Connect_Status)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Sync_Status)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TX_Status)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Timer PC_Timer;
        private System.Windows.Forms.TextBox txtComNum;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtBaudRate;
        private System.Windows.Forms.Button btn_Open;
        private System.Windows.Forms.Button btn_Close;
        //private System.Windows.Forms.Button btn_RX;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Intranet_Server_Time;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label Intranet_Server_Time_Delayed;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox Port_Connect_Status;
        private System.Windows.Forms.PictureBox Sync_Status;
        private System.Windows.Forms.PictureBox TX_Status;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label Voip_Server_Time;
    }
}

