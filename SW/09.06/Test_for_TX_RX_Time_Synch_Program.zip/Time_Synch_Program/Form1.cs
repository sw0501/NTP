﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;                  //기본 패키지에는 제공되어있지 않아서 Nuget 패키지에서 설치해야됨
using System.Runtime.InteropServices;   //시스템 시간 변경을 위해서 참조
using System.Diagnostics;               //디버깅용

namespace Time_Synch_Program
{
    public partial class Main : Form
    {
        SerialPort m_sp1;   //시리얼포트 변수

        public struct SYSTEMTIME    //public 선언안하고 쓰면 CS0051 오류 발생
        {
            public ushort wYear; 
            public ushort wMonth; 
            public ushort wDayOfWeek;
            public ushort wDay; 
            public ushort wHour; 
            public ushort wMinute; 
            public ushort wSecond;
            public ushort wMilliseconds;
        }

        [DllImport("kernel32.dll",SetLastError = true)] //SetSystemTime API를 이용하기 위한 연관 시스템 파일
        public extern static bool SetSystemTime(ref SYSTEMTIME st); //시스템 시간을 변경하는 API

        /*
        [DllImport("kernel32.dll",SetLastError = true)] //SetLocaltime API를 이용하기 위한 연관 시스템 파일
        public extern static bool SetLocalTime(ref SYSTEMTIME st);  //시스템 시간을 변경하는 API
        */

        public Main()
        {
            InitializeComponent();

            //Timer를 이용하여 현재 PC의 시간을 계속해서 갱신한다.
            PC_Timer.Enabled = true;
            PC_Timer.Tick += PC_Timer_Tick;
            /*
            Properties 안에 있는 Last_Server_Time은 DateTime 형식으로 바꿔서 사용하는게 훨씬 편할 듯 
            */
        }

        //시간이 지날때마다 PC_Timer_Tick 가 갱신됨
        private void PC_Timer_Tick(object sender, EventArgs e)
        {
            //현재 PC의 시간정보 갱신 -> 동기화가 풀려도 PC 자체 클럭으로 돌아감
            Voip_Server_Time.Text = System.DateTime.Now.ToString();

            Intranet_Server_Time.Text = Properties.Settings.Default.Last_Server_Time.ToString();                 //시간이 지날때마다 PC_Time을 갱신 -> RX 버튼을 누르거나 데이터를 받아왔을 때 갱신하면 됨
            Intranet_Server_Time_Delayed.Text = Properties.Settings.Default.Last_Server_Time_Delayed.ToString(); //시간이 지날때마다 PC_Time을 갱신 -> RX 버튼을 누르거나 데이터를 받아왔을 때 갱신하면 됨

            //연결 상태 이미지 변경 -> 포트를 열고 닫을 때, 수신이 발생했을 때 바꿔주면 됨
            if (m_sp1 == null) 
            {
                Port_Connect_Status.Image = Properties.Resources.RC1;
                Sync_Status.Image = Properties.Resources.RC1;
                TX_Status.Image = Properties.Resources.RC1;
            }
            else {
                if (m_sp1.IsOpen&&m_sp1.ReadExisting() != "")
                {
                    MessageBox.Show(m_sp1.ReadExisting());
                    TX_Status.Image = Properties.Resources.GC1;
                }
                else
                {
                    TX_Status.Image = Properties.Resources.YC1;
                }
                Port_Connect_Status.Image = Properties.Resources.GC1;
                Sync_Status.Image = Properties.Resources.GC1;
            }

            
            //매초마다 이벤트 데이터 저장받는건가?? 확인필요
            if (m_sp1 != null)
            {
                m_sp1.DataReceived += new SerialDataReceivedEventHandler(EventDataReceived);
            }
        }

        private void Main_Load(object sender, EventArgs e)
        {
            //사용자가 세팅에서 Port 이름과 BaudRate 입력하고 그 값을 받아와야함
            txtComNum.Text = "COM5";
            txtBaudRate.Text = "9600";
            Intranet_Server_Time.Text = Properties.Settings.Default.Last_Server_Time.ToString();                //속성에 저장되어있는 Last_Server_Time을 불러와서 Text에 저장
            Intranet_Server_Time_Delayed.Text = Properties.Settings.Default.Last_Server_Time_Delayed.ToString();//속성에 저장되어있는 Last_Server_Time_Delayed을 불러와서 Text에 저장
        }

        private void btn_Open_Click(object sender, EventArgs e)
        {
            try
            {
                if (null == m_sp1)
                {
                    m_sp1 = new SerialPort();
                    m_sp1.PortName = txtComNum.Text;    //컴포트명
                    m_sp1.BaudRate = Convert.ToInt32(txtBaudRate.Text); //바우드레이트
                    m_sp1.Parity = Parity.None;
                    m_sp1.DataBits = 8;
                    m_sp1.StopBits = StopBits.One;

                    m_sp1.DataReceived += new SerialDataReceivedEventHandler(EventDataReceived);
                    m_sp1.Open();
                }

                btn_Open.Enabled = false;   //Open Button Disable
                btn_Close.Enabled = true;    //Close Button Enable
            }
            catch (System.Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btn_Close_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.Last_Server_Time = System.DateTime.Now;  //Close 버튼 누를때마다 바뀐 시간 설정을 저장
            DateTime temp = System.DateTime.Now.AddSeconds(1);  //시간 지연
            Properties.Settings.Default.Last_Server_Time_Delayed = temp; //Close 버튼 누를때마다 바뀐 시간 설정을 저장
            Properties.Settings.Default.Save(); //설정 저장


            if (null != m_sp1)
            {
                if (m_sp1.IsOpen)
                {
                    m_sp1.Close();
                    m_sp1.Dispose();
                    m_sp1 = null;
                }
                btn_Open.Enabled = true;    //Open Button Enable
                btn_Close.Enabled = false;  //Close Button Disable
            }

        }

        private void EventDataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            int iRecSize = m_sp1.BytesToRead; // 수신된 데이터 갯수
            string strRxData;   //수신 데이터 문자열

            try
            {
                if (iRecSize != 0) // 수신된 데이터의 수가 0이 아닐때만 처리하자
                {
                    //Debug.WriteLine("수신된 데이터 수 : " + iRecSize);
                    strRxData = "";
                    /*
                    byte[] buff = new byte[iRecSize];

                    m_sp1.Read(buff, 0, iRecSize);

                    Debug.WriteLine(strRxData);
                    for (int iTemp = 0; iTemp < iRecSize; iTemp++)
                    {
                        strRxData += Convert.ToChar(buff[iTemp]);
                    }
                    */
                    strRxData = m_sp1.ReadExisting();
                    //Debug.WriteLine(strRxData);
                    pharsingMsg(strRxData);
                }
            }
            catch (System.Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }
        }

        //수신된 GPS 데이터에서 원하는 데이터 추출
        private void pharsingMsg(string Msg)
        {
            //string reception_time = "";     //수신시간
            int GPS_year = 0;           //연도
            int GPS_month = 0;          //월
            int GPS_day = 0;           //일
            int GPS_hour = 0;           //시
            int GPS_minute = 0;         //분
            int GPS_second = 0;         //초
            int GPS_milliseconds = 0;   //밀리초


            string[] ChkMsg = null;
            string temp = "";
            if(Msg == null || Msg.Equals(""))
            {

            }
            else
            {
                try
                {
                    Msg.Replace("\n\r", "");
                    int selectIDX = -1;
                    string[] strArr = Msg.Split('$');
                    //최근의 GPRMC 문자열 찾기
                    for(int i = strArr.Length - 1; i >= 0; i--)
                    {
                        if (strArr[i].ToString().Substring(0, 5).Equals("GPRMC"))
                        {
                            //수신 문자열이 유효하고 필요한 정보를 가지고 있는지 확인
                            ChkMsg = strArr[i].ToString().Split(',');
                            if(ChkMsg[2] == null || ChkMsg[3] == null)
                            {
                                continue;
                            }
                            else if(ChkMsg[2].ToString().Replace(" ","").Equals("")|| ChkMsg[3].ToString().Replace(" ", "").Equals(""))
                            {
                                continue;
                            }
                            else
                            {
                                selectIDX = i;
                                break;
                            }
                        }
                    }

                    //수신 문자열중 GPRMC가 없을 때
                    if(selectIDX < 0)
                    {
                        GPS_year = 0;          
                        GPS_month = 0;
                        GPS_day = 0;           
                        GPS_hour = 0;          
                        GPS_minute = 0;         
                        GPS_second = 0;        
                        GPS_milliseconds = 0;
                    }
                    else
                    {

                        string[] ArrMsg = ChkMsg;
                        temp = ArrMsg[1].ToString();


                        //SetSystemTime 이 그리니치 표준시를 사용하기 때문에 시간조정 필요 X
                        GPS_hour = Convert.ToInt16(temp.Substring(0, 2));
                        if (GPS_hour > 24)
                        {
                            GPS_hour = GPS_hour - 24;
                        }

                        //string 대신 datatime 형식으로 변환해서 사용하면 될 듯
                        GPS_minute = Convert.ToInt16(temp.Substring(2, 2));
                        GPS_second = Convert.ToInt16(temp.Substring(4, 2));
                        GPS_milliseconds = Convert.ToInt16(temp.Substring(7, 3));
                        GPS_year = 2000 + Convert.ToInt16(ArrMsg[9].Substring(4, 2));
                        GPS_month = Convert.ToInt16(ArrMsg[9].Substring(2, 2));
                        GPS_day = Convert.ToInt16(ArrMsg[9].Substring(0, 2));


                        DateTime GPS_Time = new DateTime(GPS_year,GPS_month,GPS_day,GPS_hour,GPS_minute,GPS_second,GPS_milliseconds);

                        SYSTEMTIME st = new SYSTEMTIME();

                        //tmpdata 안에 변경할 시간 정보들을 변수로 넘겨주면 된다.
                        //DateTime tmpdate = new DateTime(st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);    
                        Properties.Settings.Default.Last_Server_Time = GPS_Time;
                       
                        st.wYear = (ushort)GPS_Time.Year;
                        st.wDayOfWeek = (ushort)GPS_Time.DayOfWeek;
                        st.wMonth = (ushort)GPS_Time.Month;
                        st.wDay = (ushort)GPS_Time.Day;
                        st.wHour = (ushort)GPS_Time.Hour;
                        st.wMinute = (ushort)GPS_Time.Minute;
                        st.wSecond = (ushort)GPS_Time.Second;
                        st.wMilliseconds = (ushort)GPS_Time.Millisecond;

                        

                        bool E = SetSystemTime(ref st);

                        //에러 체크 -> 1314 : 관리자 권한 -> 빌드하고 관리자 권한으로 열기하면 됨
                        if (E == false)
                        {
                            int lastError = Marshal.GetLastWin32Error();
                            Debug.WriteLine(lastError.ToString());
                        }

                    }
                }
                catch(Exception ex)
                {
                    Debug.WriteLine(ex.Message);
                }
            }
        }

    }
}
